# text_categorizer

Requirements:

Python 3.6.4

pip install -r requirements.txt

keep 
LabelledData.txt
in the same path as textcategorizer.py file

Download 
https://github.com/mit-nlp/MITIE/releases/download/v0.4/MITIE-models-v0.2.tar.bz2 place total_word_feature_extractor.dat 
in the same path as textcategorizer.py file

Run:

python textcategorizer.py

it will train 
then validate the model
then it saves the classifier as a pickle file to disc
it will then load classifier form disk - this is just for saving and loading demonstration
validation is done on the test data - a confusion matrix plot will be shown 
close it
then a prompt to enter text will show 
enter your text here 
it will show the category prediction - ranked with confidence value for each
